<?php
defined('_JEXEC') or die('Access denied');

/*------------------------------------------------------------------------
# Full Name of JSN Extension(e.g: JSN PowerAdmin)
# ------------------------------------------------------------------------
# author    JoomlaShine.com Team
# copyright Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
# Websites: http://www.joomlashine.com
# Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
# @license - GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
# @version $Id$
-------------------------------------------------------------------------*/

require JModuleHelper::getLayoutPath('mod_poweradmin', $params->get('layout', 'default'));